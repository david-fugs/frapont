<?php

/**
 * View
 */


?>
<!DOCTYPE html>
<html lang="en">


<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Restricción IP</title>
    <link href="css/bootstrap-5.min.css" rel="stylesheet">
</head>


<body>
    <div class="d-flex align-items-center justify-content-center vh-100">
        <div class="text-center">
            <h1 class="display-1 fw-bold">Error</h1>
            <p class="fs-3"> <span class="text-danger">Opps!</span> Tu dispositivo no se encuentra entre la lista de ip permitidas para acceder a la plataforma</p>
            <p class="lead">
                Contacta con la administración
            </p>

        </div>
    </div>
</body>


</html>